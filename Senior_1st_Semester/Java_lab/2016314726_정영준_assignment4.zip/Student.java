
public class Student extends Person{
	// Parent class is Person
	private String major;
	private double tuitionFee;
	// constructor
	public Student(String fullname, int age, String major, double tuitionFee) {
		super(fullname, age);
		this.major = major;
		this.tuitionFee = tuitionFee;
	}
	// getter and setter
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public double getTuitionFee() {
		return tuitionFee;
	}
	public void setTuitionFee(double tuitionFee) {
		this.tuitionFee = tuitionFee;
	}
	
	@Override
	public void getDetail() {
		super.getDetail(); // Person's getDetail
		// print new information (Major and Tuition fee)
		System.out.printf("Major: %s\nTuition Fee: %.1f\n",this.getMajor(),this.getTuitionFee());
		
	}

}
