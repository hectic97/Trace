
public class Professor extends Staff{
	private int nResearches;
	private String mainCourse;
	// Constructor
	public Professor(String fullname, int age, String department, double salary, int nResearches, String mainCourse) {
		super(fullname, age, department, salary);
		this.nResearches = nResearches;
		this.mainCourse = mainCourse;
	}
	// getter and setter
	public int getnResearches() {
		return nResearches;
	}
	public void setnResearches(int nResearches) {
		this.nResearches = nResearches;
	}
	public String getMainCourse() {
		return mainCourse;
	}
	public void setMainCourse(String mainCourse) {
		this.mainCourse = mainCourse;
	}
	
	// Override abstract function, use super to use function in class Staff
	@Override
	public void getDetail() {
			super.getDetail();
			//print n of Researches and Main course of Professor
			System.out.printf("Number of Researches: %d\nMain Course: %s\n",this.getnResearches(),this.getMainCourse());
	}
	
}
