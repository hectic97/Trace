
public class BankAccount {
	
	private String firstName;
	private String lastName;
	private double balance;
	
	public BankAccount(String firstName, String lastName, double balance) { // constructor
		this.firstName = firstName;
		this.lastName = lastName;
		this.balance = balance;
	}

	public String getFirstName() { 
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public void Withdraw(double amount) {
		if (amount > this.balance) { // if not enough money
			System.out.println("Failed. Withdrawal amount exceeded account balance.");
		}
		else {
			// if have enough money
			this.balance -= amount; // balance = balance - amount
			System.out.println("Success."); // print success message
		}
	}
	
	public void Transfer(BankAccount receiverObject, double amount) {
		if (amount <= this.balance) { // if have enough balance
			this.balance -= amount; // withdraw
			receiverObject.setBalance(receiverObject.getBalance()+amount); // receiver's new balance = orginial receiver's balance + transferred amount 
			System.out.println("Success."); // print success message
			
		}
		else {
			// not have enough money
			System.out.println("Failed. You have not enough money!"); 
		}
		
	}
	
	
	
}
