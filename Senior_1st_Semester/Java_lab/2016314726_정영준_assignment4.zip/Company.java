
public class Company extends Place{
	// inherit class Place
	private int nEmployees;
	private double annualIncome;
	private int nDepartments;
	
	public Company(String title, int nRooms, String location, int nEmployees, double annualIncome, int nDepartments) {
		super(title, nRooms, location); // use Parent class's constructor
		this.nEmployees = nEmployees;
		this.annualIncome = annualIncome;
		this.nDepartments = nDepartments;
		
	}
	//getter and setter
	public int getnEmployees() {
		return nEmployees;
	}

	public void setnEmployees(int nEmployees) {
		this.nEmployees = nEmployees;
	}

	public double getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(double annualIncome) {
		this.annualIncome = annualIncome;
	}

	public int getnDepartments() {
		return nDepartments;
	}

	public void setnDepartments(int nDepartments) {
		this.nDepartments = nDepartments;
	}
	
	// Override toString() method
	@Override
	public String toString()
	{
		return String.format("Company: %s\nNumber of rooms: %d\nLocation: %s\nNumber of Employees: %d\nAnnual Income: %.2f\nNumber of Department: %d",
				super.getTitle(), super.getnRooms(),super.getLocation(),getnEmployees(), getAnnualIncome(), getnDepartments());
	}

}
