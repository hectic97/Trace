
public class Graduate extends Student{
	// inherit Student class
	private String researchInterest;

	public Graduate(String fullname, int age, String major, double tuitionFee, String researchInterest) {
		super(fullname, age, major, tuitionFee);
		this.researchInterest = researchInterest;
	}

	public String getResearchInterest() {
		return researchInterest;
	}

	public void setResearchInterest(String researchInterest) {
		this.researchInterest = researchInterest;
	}
	//Override getDetail
	@Override
	public void getDetail() {
		super.getDetail();
		System.out.println("Research Interest: "+this.getResearchInterest());
	}
}
