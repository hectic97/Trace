
public class Undergraduate extends Student {
	private String year; 
	// Constructor (use super to get Student's constructor)
	public Undergraduate(String fullname, int age, String major, double tuitionFee, String year) {
		super(fullname, age, major, tuitionFee);
		this.year = year;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	
	@Override
	public void getDetail() {
		super.getDetail(); //Student's getDetail
		// Print out new information - year
		System.out.println("Year: "+this.getYear());
	}

}
