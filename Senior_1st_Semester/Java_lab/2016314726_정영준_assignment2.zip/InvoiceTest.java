import java.util.Scanner; // Scanner for getting user inputs
import java.text.DecimalFormat; // for pretty float representation ex) 33.0 -> 33

public class InvoiceTest {
	
	
	
	public static void main(String args[]) {
		String name;
		int quantity;
		double price;
		
		Scanner input = new Scanner(System.in); // Scanner object
		DecimalFormat df = new DecimalFormat("##.#"); // set format
		
		System.out.print("Product name: "); 
		name = input.nextLine(); // get user's input as String type
		
		System.out.print("Quantity: ");
		quantity = input.nextInt(); // get user's input as integer type
		
		System.out.print("Price ($): ");
		price = input.nextDouble(); // get user's input as double type
		
		Invoice invoice = new Invoice(name, quantity, price); // construct new Invoice object: invoice
		
		System.out.println("Total invoice amount: $"+df.format(invoice.getInvoiceAmount())); // calculate invoice amount
		input.close();
		 // close Scanner
		
	}

}
