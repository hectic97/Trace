import java.util.Random; // import Random for random number generation
import java.util.Scanner; // import Scanner for getting user input


public class task3 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in); // create Scanner object
		int score = 0; // initialize score variable
		Random randomGenerator = new Random(); // create Random object
		int randomInt; // variable for assigning generated random number
		int answer; // variable for saving true answer
		for (int i = 0; i < 5; i++) { // iterate 5 times
			randomInt = randomGenerator.nextInt(9)+1; // generate random integer [1~9]
			answer = randomInt * randomInt; // true answer 
			
			System.out.printf("Question %d: Square of %d:",i+1,randomInt); 
			int userAnswer = input.nextInt(); // get user input as int type
			
			if (userAnswer == answer) // check user answer is same as true answer
				score++; // add 1 to score
			
			
			
		}
		System.out.printf("Number of correct answers:%d\n",score); // print score 
		if (score == 0)
			System.out.println("Try again.");
		else if (score==1)
			System.out.println("Very Bad.");
		else if (score==2)
			System.out.println("Not Bad.");
		else if (score==3)
			System.out.println("Good.");
		else if (score==4)
			System.out.println("Very Good.");
		else // (if score ==5)
			System.out.println("Excellent!");
			
		input.close();
		


	}

}
