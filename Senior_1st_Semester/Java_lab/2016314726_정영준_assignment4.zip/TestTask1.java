public class TestTask1 {

	public static void main(String[] args) {
		// Initialize object company
		Company company = new Company("Samsung Electronics",100,"Seoul",2000,1000000.00,20);
		// Initialize object university
		University university = new University("SKKU",200,"Suwon",89,100000,2000);
		System.out.println(company); // == company.getString()
		System.out.println("=======================");
		System.out.println(university);// == university.getString()
		

	}

}
