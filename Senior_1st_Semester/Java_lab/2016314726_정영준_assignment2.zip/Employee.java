public class Employee { // class Employee

	private String firstName; // String variable firstName 
	private String lastName; // String type variable lastName
	private double monthlySalary; // double type variable monthly Salary
	
	public Employee(String firstName, String lastName, double monthlySalary) { // Constructor
		this.firstName = firstName;
		this.lastName = lastName;
		this.monthlySalary = monthlySalary;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getMonthlySalary() {
		return monthlySalary;
	}

	public void setMonthlySalary(double monthlySalary) {
		if (monthlySalary > 0)  // if monthlySalary is positive number
			this.monthlySalary = monthlySalary; // set monthlysalary
	}
	
	
	
	
}
