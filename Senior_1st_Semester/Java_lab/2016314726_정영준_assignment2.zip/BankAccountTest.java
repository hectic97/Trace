import java.text.DecimalFormat; // import DecimalFormat for print out float number 

public class BankAccountTest {

	public static void main(String[] args) {
		
		
		DecimalFormat df = new DecimalFormat("##.#"); // 33.0 -> 33 when print
		BankAccount johnAccount = new BankAccount("John","Ewing",14000); // construct john account object
		BankAccount jackAccount = new BankAccount("Jack","Sparrow",100000); // construct jack account object
		
		System.out.println("Balance ->"); //print current balance of two accounts
		System.out.println(johnAccount.getFirstName()+" "+johnAccount.getLastName()+"'s balance:$"+df.format(johnAccount.getBalance())); 
		System.out.println(jackAccount.getFirstName()+" "+jackAccount.getLastName()+"'s balance:$"+df.format(jackAccount.getBalance()));
		
		
		System.out.println("Operation ->");
		System.out.println("John Ewing withdrew 2000$");
		johnAccount.Withdraw(2000); // withdraw 2000$
		
		
		System.out.println("Balance ->"); //print current balance of two accounts
		System.out.println(johnAccount.getFirstName()+" "+johnAccount.getLastName()+"'s balance:$"+df.format(johnAccount.getBalance()));
		System.out.println(jackAccount.getFirstName()+" "+jackAccount.getLastName()+"'s balance:$"+df.format(jackAccount.getBalance()));
		
		
		System.out.println("Operation ->");
		System.out.println("Jack Sparrow trasferred $50000 to John Ewing"); 
		jackAccount.Transfer(johnAccount, 50000); //transfer $50000 
		
		
		System.out.println("Balance ->"); //print current balance of two accounts
		System.out.println(johnAccount.getFirstName()+" "+johnAccount.getLastName()+"'s balance:$"+df.format(johnAccount.getBalance()));
		System.out.println(jackAccount.getFirstName()+" "+jackAccount.getLastName()+"'s balance:$"+df.format(jackAccount.getBalance()));
		
		
		System.out.println("Operation ->");
		System.out.println("Jack Sparrow withdrew $60000"); 
		jackAccount.Withdraw(60000); //withdraw 60000$
		
		
		System.out.println("Balance ->"); //print current balance of two accounts
		System.out.println(johnAccount.getFirstName()+" "+johnAccount.getLastName()+"'s balance:$"+df.format(johnAccount.getBalance()));
		System.out.println(jackAccount.getFirstName()+" "+jackAccount.getLastName()+"'s balance:$"+df.format(jackAccount.getBalance()));
		
		
		System.out.println("Operation ->");
		System.out.println("Jack Sparrow transferred $55000 to John Ewing");
		jackAccount.Transfer(johnAccount, 55000); // trasnfer 55000$
		
		
		System.out.println("Balance ->"); //print current balance of two accounts
		System.out.println(johnAccount.getFirstName()+" "+johnAccount.getLastName()+"'s balance:$"+df.format(johnAccount.getBalance()));
		System.out.println(jackAccount.getFirstName()+" "+jackAccount.getLastName()+"'s balance:$"+df.format(jackAccount.getBalance()));
		
		

	}

}
