import java.util.Scanner; // import Scanner for get user input

public class task1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in); // Scanner object 
		System.out.print("Radius (cm): "); // 
		double radius = input.nextDouble(); // Get user input as double type
		System.out.print("Height (cm): ");
		double height = input.nextDouble(); // Get user input as double type
		double volume = 3.14 * radius * radius * height; 
		// pi * radius * radius * height : formula for calculating volume of the cylinder
		
		System.out.println("Volume of the cylinder: "+ volume); 
		// print out result
		input.close();

	}

}
