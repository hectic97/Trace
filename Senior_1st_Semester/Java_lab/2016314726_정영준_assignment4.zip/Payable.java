// Interface Payable
public interface Payable {
	double calculatePayment(); // Abstract method
}

