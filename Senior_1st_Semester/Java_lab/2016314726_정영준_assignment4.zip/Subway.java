
public class Subway extends PublicTransport{
	private double oneTimePayment;
	//inherit PublicTransport Class
	public Subway(String model, double oneTimePayment) {
		super(model); //Parent's constructor
		this.oneTimePayment = oneTimePayment;
	}
	// getter and setter
	public double getOneTimePayment() {
		return oneTimePayment;
	}

	public void setOneTimePayment(double oneTimePayment) {
		this.oneTimePayment = oneTimePayment;
	}
	//Override Payment's abstract method
	@Override
	public double calculatePayment() {
		return (this.getOneTimePayment());
		// In Subway, total fare = one-time payment
	}
	//Override function getDetail of PublicTransport
	@Override
	public void getDetail() {
		System.out.println("=========================");
		System.out.println("Transport type: Subway");
		super.getDetail();
		// total fare = one-time payment
		System.out.printf("One-time Payment: %.1f\nTotal Fare: %.1f\n",
				this.getOneTimePayment(),this.calculatePayment());
				
	}
	
}
