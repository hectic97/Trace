
public class Bus extends PublicTransport{
	private int nStations;
	private double farePerStation;
	// Constructor
	public Bus(String model, int nStations, double farePerStation) {
		super(model);
		this.nStations = nStations;
		this.farePerStation = farePerStation;
	}
	// Getter and setter
	public int getnStations() {
		return nStations;
	}
	public void setnStations(int nStations) {
		this.nStations = nStations;
	}
	public double getFarePerStation() {
		return farePerStation;
	}
	public void setFarePerStation(double farePerStation) {
		this.farePerStation = farePerStation;
	}
	//Override Payable's abstract method
	@Override
	public double calculatePayment() {
		return (this.getnStations() * this.getFarePerStation());
	}
	// Override get Detail of PublicTransport
	@Override
	public void getDetail() {
		System.out.println("=========================");
		System.out.println("Transport type: Bus");
		super.getDetail();
		// total fare = nStation * fare per station
		System.out.printf("Fare per stations: %.1f\nNumber of stations: %d\nTotal Fare: %.1f\n",
				this.getFarePerStation(),this.getnStations(),this.calculatePayment());
	}
	
}
