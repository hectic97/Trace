public abstract class PublicTransport implements Payable{
	private String model;
	// implements Payable which has abstract method: calculatePayment
	public PublicTransport(String model) {
		// Constructor
		this.model = model;
	}
	//getter and setter
	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}
	// getDatail print out public transport's model
	public void getDetail() {
		System.out.println("Model: "+this.getModel());
	}
	
	
	
	
	
	

}
