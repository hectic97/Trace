public class Cab extends PublicTransport{
	//inherit abstract class PublicTransport
	private double baseFare;
	private double farePerKm;
	private double distance;
	// 
	public Cab(String model, double baseFare, double farePerKm, double distance) {
		super(model); // Transport's constructor
		this.baseFare = baseFare;
		this.farePerKm = farePerKm;
		this.distance = distance;
	}
	// getter and setter
	public double getBaseFare() {
		return baseFare;
	}
	public void setBaseFare(double baseFare) {
		this.baseFare = baseFare;
	}
	public double getFarePerKm() {
		return farePerKm;
	}
	public void setFarePerKm(double farePerKm) {
		this.farePerKm = farePerKm;
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	// Override Payable's abstract method
	@Override
	public double calculatePayment() {
		// total fare = base fare  + farePerKm * distance
		return (this.baseFare+this.distance*this.farePerKm);
	}
	
	//Override getDetail of PublicTransport
	@Override
	public void getDetail() {
		System.out.println("=========================");
		System.out.printf("Transport type: Cab\n");
		super.getDetail(); // print out model
		System.out.printf("Base Fare: %.1f\nFare per km: %.1f\nDistancd: %.1f\nTotal Fare: %.1f\n",
				this.getBaseFare(),this.getFarePerKm(),this.getDistance(),this.calculatePayment());
	}
	
	
}
