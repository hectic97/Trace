import java.text.DecimalFormat; // for pretty format float

public class EmployeeTest {

	public static void main(String args[]) {
		Employee john = new Employee("John","Ewing",3000 ); // Employee john object constructed
		Employee jack = new Employee("Jack", "Sparrow",100000); // Employee jack object constructed
		
		DecimalFormat df = new DecimalFormat("##.#"); // ex) 33.0 -> 33 when print
		
		// print current employees's monthly salary
		System.out.println(john.getFirstName()+' '+john.getLastName()+
				"'s salary:$"+df.format(john.getMonthlySalary()));
		System.out.println(jack.getFirstName()+' '+jack.getLastName()+
				"'s salary:$"+df.format(jack.getMonthlySalary()));
		
		john.setMonthlySalary(john.getMonthlySalary()*1.05); // raise john's salary 5% 
		jack.setMonthlySalary(jack.getMonthlySalary()*1.05); // raise jack's salary 5%
		System.out.println("After raise by 5%");
		System.out.println(john.getFirstName()+' '+john.getLastName()+
				"'s salary:$"+df.format(john.getMonthlySalary()));
		System.out.println(jack.getFirstName()+' '+jack.getLastName()+
				"'s salary:$"+df.format(jack.getMonthlySalary()));
		
		
	}
}
