public class Staff extends Person{
	// inherit Person
	private String department;
	private double salary;
	// Constructor
	public Staff(String fullname, int age, String department, double salary) {
		super(fullname, age);
		this.department = department;
		this.salary = salary;
	}
	// getter and setter
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	// Override
	@Override
	public void getDetail() {
		super.getDetail();// print out fullname and age.
		// print out Salary and Department of staff
		System.out.printf("Salary: %.1f\nDepartment: %s\n",this.getSalary(),this.getDepartment());;
	}
	
}
