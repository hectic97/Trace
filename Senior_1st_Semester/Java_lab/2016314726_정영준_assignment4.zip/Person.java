public class Person {
	private String fullname;
	private int age;
	// initialize variable 
	public Person(String fullname, int age) {
		this.fullname = fullname;
		this.age = age;
	}
	// getter and setter
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void getDetail() {
		System.out.println("==============================");
		// print out fullname and age of person
		System.out.printf("Full name: %s\nAge: %d\n",this.getFullname(),this.getAge());
	}
	

}
