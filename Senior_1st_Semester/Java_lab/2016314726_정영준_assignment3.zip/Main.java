import java.util.Scanner;


public class Main {

	public static void mainMenu() { // print out main menu
		System.out.print("1. Check balance (Enter 1);\n2. Withdraw money (Enter 2);\n3. Last Operation (Enter 3);\n0. Exit (Enter 0);\n");
	}
	
	public static void checkBalance(BankAccount currentAccount) {
		System.out.println("User: "+currentAccount.getFullname()); // show account user's name
		System.out.println("Balance: "+currentAccount.getBalance()); // show account's balance
		currentAccount.setLastOperation("Check balance"); // set current account's last operation = "check balance"
	}
	
	public static void withdrawMoney(BankAccount currentAccount, Scanner scan) {
		System.out.print("Enter amount: "); 
		double amount = scan.nextDouble(); // scan double type amount value
		currentAccount.Withdraw(amount); // use BackAccount's withdraw method (if amount < balance, withdraw) 
		currentAccount.setLastOperation("Withdrawal"); // set current account's last operation = "withdrawal"
	}
	
	public static void lastOperation(BankAccount currentAccount) {
		System.out.println("Name: "+currentAccount.getFullname()); // print out name, current balance, last operation
		System.out.println("Current Balance: "+currentAccount.getBalance());
		System.out.println("Last Operation: "+currentAccount.getLastOperation());
	}
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in); //scanner for getting user's input
		BankAccount account1 = new BankAccount("Firuz","firuz","p@ssw0rd",2000.0); // account1
		BankAccount account2 = new BankAccount("Kang Seong","kang","p@ssw0rd123",34000.0); // account2
		BankAccount account3 = new BankAccount("SiHyeon Ryu","ryu","p@ssw0rd1234",10000.0); // account3
		int userChoice = 1; // initializing userChoice for entering  while statement in line 58
		BankAccount currentAccount;
		
		while (true) {
			System.out.println("Login");
			System.out.print("Username: ");
			String scanUsername = scan.nextLine(); // get Username
			System.out.print("Password: ");
			String scanPassword = scan.nextLine(); // get Password
			
			if (scanUsername.equals(account1.getUsername()) && scanPassword.equals(account1.getPassword())) { // check username & password
				currentAccount = account1;
				break;
			}
			else if (scanUsername.equals(account2.getUsername()) && scanPassword.equals(account2.getPassword())) {
				currentAccount = account2;
				break;
			}
			else if (scanUsername.equals(account3.getUsername()) && scanPassword.equals(account3.getPassword())) {
				currentAccount = account3;
				break;
			}
		}
		while (userChoice > 0) {
			mainMenu(); // show main menu
			userChoice = scan.nextInt();
			if (userChoice == 1)
				checkBalance(currentAccount);
			else if (userChoice == 2)
				withdrawMoney(currentAccount, scan); // have to scan user's input (amount of withdrawal)
			else if (userChoice == 3)
				lastOperation(currentAccount);
			else if (userChoice > 3)
				System.out.println("Please Enter valid number");
		}
		// user inputs 0
		System.out.println("Thank you for banking with us!");
		scan.close(); // close Scanner
		System.exit(0); // terminate program
		
	}

}
