
public class TestTask3 {

	public static void main(String[] args) {
		
		Cab cab = new Cab("BMW", 10, 5.0, 7.0);
		Bus bus = new Bus("Mercedes-Benz",10,1.5);
		Subway subway = new Subway("Shinkansen",80);
		
		cab.getDetail();
		bus.getDetail();
		subway.getDetail();

	}

}
