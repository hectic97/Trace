
public class University extends Place{
	private int rank;
	private int nStudents;
	private int nTeachers;
	
	public University(String title, int nRooms, String location, int rank, int nStudents, int nTeachers) {
		super(title, nRooms, location);// Place's variable
		this.rank = rank;
		this.nStudents = nStudents;
		this.nTeachers = nTeachers;
	}
	// getter and setter
	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public int getnStudents() {
		return nStudents;
	}

	public void setnStudents(int nStudents) {
		this.nStudents = nStudents;
	}

	public int getnTeachers() {
		return nTeachers;
	}

	public void setnTeachers(int nTeachers) {
		this.nTeachers = nTeachers;
	}
	// Override toString() method.
	@Override
	public String toString()
	{
		return String.format("University: %s\nNumber of rooms: %d\nLocation: %s\nRank: %d\nNumber of Students: %d\nNumber of Teachers: %d",
				super.getTitle(), super.getnRooms(), super.getLocation(), getRank(), getnStudents(), getnTeachers());
	}
	

}
