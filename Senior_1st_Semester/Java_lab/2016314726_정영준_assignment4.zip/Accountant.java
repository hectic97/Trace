
public class Accountant extends Staff{
	private int officeNo;

	public Accountant(String fullname, int age, String department, double salary, int officeNo) {
		super(fullname, age, department, salary);
		this.officeNo = officeNo;
	}

	public int getOfficeNo() {
		return officeNo;
	}

	public void setOfficeNo(int officeNo) {
		this.officeNo = officeNo;
	}
	
	@Override
	public void getDetail() {
		super.getDetail(); // Staff's get Detail
		// print Office Number
		System.out.println("Office Number: "+this.officeNo);
		
	}
}
