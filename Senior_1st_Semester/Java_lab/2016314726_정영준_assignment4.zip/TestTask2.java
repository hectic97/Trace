
public class TestTask2 {

	public static void main(String[] args) {
		
		// Create object of each Class
		Professor professor = new Professor("Frank George",56,"Computing",10000.0,45,"Java");
		Accountant accountant = new Accountant("Jack Sparrow",25,"International",2300.0,305);
		Graduate graduate = new Graduate("Firuz Juraev",29,"Computing",16000.0,"Healthcare");
		Undergraduate undergraduate = new Undergraduate("Mike Shinoda",19,"Computing",12000.0,"Freshman");
		
		// get Detail of all objects.
		professor.getDetail();
		accountant.getDetail();
		graduate.getDetail();
		undergraduate.getDetail();

	}

}
