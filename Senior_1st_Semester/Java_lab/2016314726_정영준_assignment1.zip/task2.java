import java.util.Scanner; // import Scanner to get user input

public class task2 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in); // create Scanner object
		System.out.print("Payment for one hour ($): ");
		double payforhour = input.nextDouble(); // get pay for hour as double type
		System.out.print("Payment for one extra hour ($): ");
		double payforextrahour = input.nextDouble(); // get pay for extra hour as double type
		System.out.print("Number of hours: "); 
		double hours = 	input.nextDouble(); // get number of total work hours
		double regularhours; // variable represent regular working hours
		double extrahours; // variable represent extra working hours
		
		if (hours <= 40 ) { // if extra working not happened
			regularhours = hours;
			extrahours = 0;
		}
		else { // if extra working happened
			regularhours = 40; 
			extrahours = hours - 40; // total hours - 40 is extra working hours 
		}
		
		double payregularhours = payforhour*regularhours; // calculate regular hours pay
		double payextrahours = payforextrahour*extrahours; // calculate extra hours pay
		
		
		System.out.printf("Payment for regular hours ($):%d\n",(int)payregularhours);
		System.out.printf("Payment for extra hours ($):%d\n",(int)payextrahours);
		System.out.printf("Total Payment ($):%d\n",(int)(payregularhours+payextrahours));
		input.close();
		
		

	}

}
