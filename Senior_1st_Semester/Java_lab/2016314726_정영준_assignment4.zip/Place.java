
public class Place {
	private String title;
	private int nRooms;
	private String location;
	// constructor
	public Place(String title, int nRooms, String location) {
		this.title = title;
		this.nRooms = nRooms;
		this.location = location;
	}
	// getter and setter
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getnRooms() {
		return nRooms;
	}
	public void setnRooms(int nRooms) {
		this.nRooms = nRooms;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	// toString method, this will be overridden by child Class
	public String toString() {
		return String.format("%s",this.title);
	}
	
	

}
