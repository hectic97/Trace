public class BankAccount {
	
	private String fullname;
	private String username;
	private String password;
	private double balance;
	private String lastOperation;
	
	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getLastOperation() {
		return lastOperation;
	}

	public void setLastOperation(String lastOperation) {
		this.lastOperation = lastOperation;
	}

	public BankAccount(String fullname, String username, String password, double balance) {
		this.fullname = fullname;
		this.username = username;
		this.password = password;
		this.balance = balance;
		this.lastOperation = "This is first operation."; // constructor initialize lastOperation 
	}

	public void Withdraw(double amount) {
		if (amount > this.balance) { // if not enough money
			System.out.println("Withdrawal amount exceeded account balance.");
		}
		else {
			// if have enough money
			this.balance -= amount; // balance = balance - amount
		}
	}
		
}
	
	

